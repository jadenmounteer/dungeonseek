#imports
from random import randint
import classes_and_objects

#FUNCTIONS (Spawn enemies)
def spawn_dungeon1_enemy(random_number):
    '''This function will spawn an enemy in the Tomb of the Undead dungeon. Using an if statement and a random number, an object is created for a monster. 
    This function is called in every room of the dungeon_level_1() function. Have 5-10 enemies for the first dungeon.'''

    if random_number == 1:
        #Spawn Jeff the zombie and give a short description using the appear() function.
        zombie1 = classes_and_objects.Zombie("Jeff the zombie", 20, 15, "alive", 10, 20, "Fire", 0, "", 0)
        print()
        zombie1.appear()
        print()
        #Triggers combat between Jeff the zombie and the player.
        combat_1v1(classes_and_objects.player, zombie1)

    elif random_number == 2:
        print("A knife weilding zombie appears.")
        zombie2 = classes_and_objects.Zombie("Knife weilding Zombie", 10, 40, "alive", 15, 20, "Fire", 0, "", 0)
        print()
        
        combat_1v1(classes_and_objects.player, zombie2)
    elif random_number == 3:
        print("A quiz ghost appears.")
        QUizghost = classes_and_objects.Quiz_Poltergiest("quiz ghost", 30, 20, 50, 30, "Psychic")
        print()
        combat_1v1(classes_and_objects.player, QUizghost)
def spawn_dungeon1_boss(random_number):
    '''This function will spawn a boss in the Tomb of the Undead dungeon. Using an if statement and a random number, an object is created for a boss. 
    This function is called in every room of the dungeon_level_1() function. With each room, the chances that the boss will spawn increases.'''

    if random_number == 1:
        #Spawn Blade the Vampire
        blade = classes_and_objects.Vampire("Blade", 20, 15, "alive", 10)
        #blade.appear()
        print()
        #Jeff moans by calling the battle_cry() function from the Zombie class.
        #blade.battle_cry() 


#FUNCTIONS (Rooms and locations and their descriptions.)
def dungeon_level_1_description_generator(random_number):
    '''This function generates a random description of a room based on the random_number parameter. Add maybe 10-15 different descriptions.'''
    if random_number == 1:
        return "You enter a dark and foreboding room."
    elif random_number == 2:
        return "You enter a cavern lined with coffins on the walls."
    elif random_number == 3:
        return "You traverse a dark and stoney passageway until emerging in a cold and dark stoney room."
    elif random_number == 4:
        return """You make your way down a series of stoney stone steps. After a while you see torchlight coming from below.
 You continue until you emerge in a dimly lit tomb."""
    elif random_number == 5:
        return "You emerge into a dark cathedral. Moonlight seeps in from the stainglass windows and illuminates a series of pews."
    elif random_number == 6:
        return """You emerge into the open night. Looking around, you see damp grass littered with broken tombstones and open graves.
 A full and foreboding moon shines overhead."""
    elif random_number == 7:
        return """Soon you begin to feel damp soil with every step. The air turns cold and you enter a cavern. Stalagtites dot the ceiling.
 As you near a chamber, you begin to make out dim torchlite. As it grows closer, it illuminates a table littered with ancient bones."""
    elif random_number == 8:
        return """Suddenly, you free fall and hit the ground hard snapping bones as you hit. Dazed, you get your bearings and realize 
 that you didn't break your bones, but you landed on a pile of them. You seem to be in a pit. Someone had laid a trap."""

def dungeon_level_1():
    '''This is the first dungeon (series of rooms) the player enters in the game. He will be introduced to the object of the game and will encounter a level 1 monster which will be randomly 
    picked from the level 1 monsters list.'''

    #If player.location = 0, the player talks with the trader and the trader introduces the player to the object of the game. For later
    #levels, the player can barter with the trader. Maybe make a trader() function.
    print()
    print("Hello stranger. I am the trader. I'll have more to say later on, but for now, move into that room.")
    print()
    input("Press ENTER to enter the Tomb of the Undead.")


    #Changes the location of the player to the first room and dungeon.
    classes_and_objects.player.room_location += 1
    classes_and_objects.player.dungeon_location = "Tomb of the Undead."
    #combat_1v1(player, zombie1)

    #Loop: The player battles through a series of 5 rooms. When he has battled through them, the loop breaks.
    while classes_and_objects.player.room_location <= 5:
        print()
        print("You enter room " + str(classes_and_objects.player.room_location) + " of " + classes_and_objects.player.dungeon_location)
        input("Press ENTER to continue.")
        print()

        #uses a random function and an if statement to randomly generate a description of the room using the dungeon_room_description() function.
        random_number = randint(1, 8)
        print(dungeon_level_1_description_generator(random_number))
        input("Press ENTER to continue.")

        #Generates a random number and calls the spawn_dungeon1_enemy() function to spawn an enemy for the player to face.
        #random_number = randint(1, 3)
        random_number = 1 #spawns a zombie for testing purposes.
        spawn_dungeon1_enemy(random_number)

        #Randomly generates loot inside of the room.

        #Checks to see if the player is dead. If so, it breaks out of the loop.
        if classes_and_objects.player.player_status == "Dead":
            break
        #calls the refresh() function to see if you are dead or need to level up.
        refresh()

        #Increments the room location number to make the player move onto the next room.
        classes_and_objects.player.room_location += 1

        #As you enter more rooms, increases the chance of spawing the boss.

    #If the player is dead, the player is told how many rooms he made it through and is taken back to the main function.
    if classes_and_objects.player.player_status == "Dead":
            print("You made it through " + str(classes_and_objects.player.room_location) + " room(s) in Tomb of the Undead.")
            return ""

    print("You made it through " + classes_and_objects.player.dungeon_location)
    #Sets the room location to 0 again in preparation for the next dungeon.
    classes_and_objects.player.room_location = 0


    #The room is set back to zero and the player moves onto the next dungeon where he meets with the trader again.

#FUNCTIONS (Flow of the game)
def combat_1v1(player, e):
    '''
    This function simulates 1v1 combat. The x parameter is the player and the e parameter is the enemy.
    The function first checks to see who wil attack first. Then, based on who goes first, it calls the turn function. These functions return...
    
    '''
    print(player.player_name + " and " + e.name + " enter combat.")
    #changes the player_in_combat function to True
    player.player_in_combat = True
    print()
    print(player.battle_cry())
    print()
    print(e.battle_cry())
    input("Press ENTER to continue.")

    #Generates a random number to decide who goes first.
    who_attacks_first = randint(1, 2)
    player_attacks_first = False
    enemy_attacks_first = False
    if who_attacks_first == 1:
        player_attacks_first = True  
    elif who_attacks_first == 2:
        enemy_attacks_first = True

    #Calls the attack functions specific to each class for whoever goes first. Maybe make this a while loop.

    # if the player attacks first:
    if player_attacks_first == True:
        while player.hit_points > 0 or e.hit_points > 0:
            #player.player_turn()
            print()
            player.player_turn()
            # Determines the base amount of damage caused by the attack.
            #This determines if the player is attacking with the enemy's weakness. If he is, it does 5 extra damage.
            if player.attacking_with == e.weakness:
                player.base_amount_of_damage += 5
                print(player.attacking_with + " is " + e.name + "'s weakness!")
                print()
            #Determines whether or not you miss. Your base amount of damage should be greater than the enemy's armor / 2. If not, your amount of damage is set to 0. This won't happen if the player is healing himself.
            if player.base_amount_of_damage < e.armor / 2 and player.attacking_with != "Healing":
                print("You miss!")
                player.base_amount_of_damage = 0
            print("You do " + str(player.base_amount_of_damage) + " points of damage!")
            print()
            e.hit_points = e.hit_points - player.base_amount_of_damage
            print(e.name + " hit points = " + str(e.hit_points))
            input("Press ENTER to continue.")
            #if the enemy dies...
            if e.hit_points <= 0:
                #Calls a function taking what the player was attacking with as a parameter. The function outputs the description of the enemy's death.
                print(e.death(player.attacking_with))
                print(e.name + " defeated.")
                input("Press ENTER to continue.")
                break
            print()
            #Enemy's turn
            #calls the e.turn() function specific to the enemy which determines the base amount of damage caused by the enemy's attack using the e.base_amount_of_damgage attribute.
            print(e.turn())
            #Sets the base amount of damage done to the player to 0 if the enemy is attacking with healing.
            if e.attacking_with == "Healing":
                e.base_amount_of_damage = 0
            #Determines whether or not the enemy misses judging by the player's armor class.
            if e.base_amount_of_damage < player.armor_skill / 2 and e.attacking_with != "Healing":
                print(e.name + " misses!")
                e.base_amount_of_damage = 0
            print(e.name +  " does " + str(e.base_amount_of_damage) + " points of damage to you!")
            player.hit_points = player.hit_points - e.base_amount_of_damage
            input("Press ENTER to continue.")
            print()
            if player.hit_points <= 0:
                print("You died.")
                classes_and_objects.player.player_status = "Dead"
                return

    #if the enemy attacks first
    elif enemy_attacks_first == True:
        while e.hit_points > 0 or player.hit_points > 0:
            print(e.turn())
            #Sets the base amount of damage done to the player to 0 if the enemy is attacking with healing.
            if e.attacking_with == "Healing":
                e.base_amount_of_damage = 0
            #Determines whether or not the enemy misses judging by the player's armor class.
            if e.base_amount_of_damage < player.armor_skill / 2 and e.attacking_with != "Healing":
                print(e.name + " misses!")
                e.base_amount_of_damage = 0
            print(e.name +  " does " + str(e.base_amount_of_damage) + " points of damage to you!")
            player.hit_points = player.hit_points - e.base_amount_of_damage
            input("Press ENTER to continue.")
            print()
            if player.hit_points <= 0:
                print("You died.")
                classes_and_objects.player.player_status = "Dead"
                return
            #player's turn
            player.player_turn()
            # Determines the base amount of damage caused by the attack.
            #This determines if the player is attacking with the enemy's weakness. If he is, it does 5 extra damage.
            if player.attacking_with == e.weakness:
                player.base_amount_of_damage += 5
                print(player.attacking_with + " is " + e.name + "'s weakness!")
                print()
            #Determines whether or not you miss. Your base amount of damage should be greater than the enemy's armor / 2. This won't happen if the player is healing himself.
            if player.base_amount_of_damage < e.armor / 2 and player.attacking_with != "Healing":
                print("You miss!")
                player.base_amount_of_damage = 0
            print("You do " + str(player.base_amount_of_damage) + " points of damage!")
            print()
            e.hit_points = e.hit_points - player.base_amount_of_damage
            print(e.name + " hit points = " + str(e.hit_points))
            input("Press ENTER to continue")
            print()
            if e.hit_points <= 0:
                #Calls a function taking what the player was attacking with as a parameter. The function outputs the description of the enemy's death.
                print(e.death(player.attacking_with))
                print(e.name + " defeated.")
                input("Press ENTER to continue.")
                break
    #Changes the player_in_combat variable to False
    player.player_in_combat = False
        
def player_dead():
    '''This function checks to see if the player is still alive. If so, the game goes on, if not, it is game over. Each enemy class will have a specific death that they will cause the player to experience.
    The function will account for the enemy the player is engaging and use the following code to get the death: enemy.death(). This function could also check to see if you've won the game.'''
def level_up():
    '''
    This function checks to see if the player has enough points to level up. If he does, he is given 5 points to allocate to whichever skills he chooses.
    The function also notifies you of new attacks and spells that you can use when you increase in level with each attribute.

    '''
    #right now, the player levels up at every 10 experience points gained. He is also given 5 points to allocate to skills. We can change this later on.
    if classes_and_objects.player.experience_points == 10:
        classes_and_objects.player.points_to_allocate = 5
        classes_and_objects.player.player_level = classes_and_objects.player.player_level + 1
        print("______________")
        print()
        print("  LEVEL UP!")
        print("______________")
        print()
        print("You are now level: " + str(classes_and_objects.player.player_level))
        #lets the player allocate points to his skills.
        while classes_and_objects.player.points_to_allocate != 0:
            print()
            print("You have " + str(classes_and_objects.player.points_to_allocate) + " points to allocate.")
            print("Which skill would you like to allocate points to?")
            print()
            print("1  Hit Points: " + str(classes_and_objects.player.hit_points))
            print("2  Sword skill: " + str(classes_and_objects.player.sword_skill))
            print("3  Archery skill: " + str(classes_and_objects.player.archery_skill))
            print("4  Magic skill: " + str(classes_and_objects.player.magic_skill))
            print("5  Armor skill: " + str(classes_and_objects.player.armor_skill))
            print("6  Barter skill: " + str(classes_and_objects.player.barter_skill))
            print("7  Speed: " + str(classes_and_objects.player.speed))
            print("8  Stealth: " + str(classes_and_objects.player.stealth))
            print("9  Strength: " + str(classes_and_objects.player.strength))
            print()
            skill_to_allocate_points_to = input("Type the number of the skill you want to allocate points to: ")
            #Checks to see if the string entered was correct:
            while skill_to_allocate_points_to != "1":
                if skill_to_allocate_points_to == "2":
                    break
                elif skill_to_allocate_points_to == "3":
                    break
                elif skill_to_allocate_points_to == "4":
                    break
                elif skill_to_allocate_points_to == "5":
                    break
                elif skill_to_allocate_points_to == "6":
                    break
                elif skill_to_allocate_points_to == "7":
                    break
                elif skill_to_allocate_points_to == "8":
                    break
                elif skill_to_allocate_points_to == "9":
                    break
                skill_to_allocate_points_to = input("That number does not exist. Please type the number of the skill you want to allocate points to: ")
           
            #Using the skill the player chose, the user is now asked how many points he wants to allocate to that skill.

            #Hit Points
            if skill_to_allocate_points_to == "1":
                quantity_of_points_to_add = input("How many points would you like to add to your hit points? ")
                points_added = False
                while points_added == False:
                    if quantity_of_points_to_add == "1": 
                        classes_and_objects.player.max_hit_points = classes_and_objects.player.max_hit_points + 1
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 1
                        num_of_points_added = 1
                        points_added = True
                    elif quantity_of_points_to_add == "2":
                        classes_and_objects.player.max_hit_points = classes_and_objects.player.max_hit_points + 2
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 2
                        num_of_points_added = 2
                        points_added = True
                    elif quantity_of_points_to_add == "3":
                        classes_and_objects.player.max_hit_points = classes_and_objects.player.max_hit_points + 3
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 3
                        num_of_points_added = 3
                        points_added = True
                    elif quantity_of_points_to_add == "4":
                        classes_and_objects.player.max_hit_points = classes_and_objects.player.max_hit_points + 4
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 4
                        num_of_points_added = 4
                        points_added = True
                    elif quantity_of_points_to_add == "5":
                        classes_and_objects.player.max_hit_points = classes_and_objects.player.max_hit_points + 5
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 5
                        num_of_points_added = 5
                        points_added = True
                    else:
                        quantity_of_points_to_add = input("Please enter a number from 1-5: ")
                #while loop that checks to see if you're trying to add too many points. If you added too many points, it fixes the issue.
                while num_of_points_added > (classes_and_objects.player.points_to_allocate + num_of_points_added): 
                    print("You cannot add more points than you have.")
                    classes_and_objects.player.max_hit_points = classes_and_objects.player.max_hit_points - num_of_points_added
                    classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate + num_of_points_added
                    break
                print("Your total hit points is now: " + str(classes_and_objects.player.max_hit_points))

            #Sword skill
            if skill_to_allocate_points_to == "2":
                quantity_of_points_to_add = input("How many points would you like to add to your sword skill? ")
                points_added = False
                while points_added == False:
                    if quantity_of_points_to_add == "1":
                        classes_and_objects.player.sword_skill = classes_and_objects.player.sword_skill + 1
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 1
                        num_of_points_added = 1
                        points_added = True
                    elif quantity_of_points_to_add == "2":
                        classes_and_objects.player.sword_skill = classes_and_objects.player.sword_skill + 2
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 2
                        num_of_points_added = 2
                        points_added = True
                    elif quantity_of_points_to_add == "3":
                        classes_and_objects.player.sword_skill = classes_and_objects.player.sword_skill + 3
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 3
                        num_of_points_added = 3
                        points_added = True
                    elif quantity_of_points_to_add == "4":
                        classes_and_objects.player.sword_skill = classes_and_objects.player.sword_skill + 4
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 4
                        num_of_points_added = 4
                        points_added = True
                    elif quantity_of_points_to_add == "5":
                        classes_and_objects.player.sword_skill = classes_and_objects.player.sword_skill + 5
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 5
                        num_of_points_added = 5
                        points_added = True
                    else:
                        quantity_of_points_to_add = input("Please enter a number from 1-5: ")
                #while loop that checks to see if you're trying to add too many points. If you added too many points, it fixes the issue.
                while num_of_points_added > (classes_and_objects.player.points_to_allocate + num_of_points_added): 
                    print("You cannot add more points than you have.")
                    classes_and_objects.player.sword_skill = classes_and_objects.player.sword_skill - num_of_points_added
                    classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate + num_of_points_added
                    break
                print("Your sword skill is now: " + str(classes_and_objects.player.sword_skill))

            #Archery skill
            if skill_to_allocate_points_to == "3":
                quantity_of_points_to_add = input("How many points would you like to add to your archery skill? ")
                points_added = False
                while points_added == False:
                    if quantity_of_points_to_add == "1":
                        classes_and_objects.player.archery_skill = classes_and_objects.player.archery_skill + 1
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 1
                        num_of_points_added = 1
                        points_added = True
                    elif quantity_of_points_to_add == "2":
                        classes_and_objects.player.archery_skill = classes_and_objects.player.archery_skill + 2
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 2
                        num_of_points_added = 2
                        points_added = True
                    elif quantity_of_points_to_add == "3":
                        classes_and_objects.player.archery_skill = classes_and_objects.player.archery_skill + 3
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 3
                        num_of_points_added = 3
                        points_added = True
                    elif quantity_of_points_to_add == "4":
                        classes_and_objects.player.archery_skill = classes_and_objects.player.archery_skill + 4
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 4
                        num_of_points_added = 4
                        points_added = True
                    elif quantity_of_points_to_add == "5":
                        classes_and_objects.player.archery_skill = classes_and_objects.player.archery_skill + 5
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 5
                        num_of_points_added = 5
                        points_added = True
                    else:
                        quantity_of_points_to_add = input("Please enter a number from 1-5: ")
                #while loop that checks to see if you're trying to add too many points. If you added too many points, it fixes the issue.
                while num_of_points_added > (classes_and_objects.player.points_to_allocate + num_of_points_added): 
                    print("You cannot add more points than you have.")
                    classes_and_objects.player.archery_skill = classes_and_objects.player.archery_skill - num_of_points_added
                    classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate + num_of_points_added
                    break
                print("Your archery skill is now: " + str(classes_and_objects.player.archery_skill))
            
            #Magic skill
            if skill_to_allocate_points_to == "4":
                quantity_of_points_to_add = input("How many points would you like to add to your magic skill? ")
                points_added = False
                while points_added == False:
                    if quantity_of_points_to_add == "1":
                        classes_and_objects.player.magic_skill = classes_and_objects.player.magic_skill + 1
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 1
                        num_of_points_added = 1
                        points_added = True
                    elif quantity_of_points_to_add == "2":
                        classes_and_objects.player.magic_skill = classes_and_objects.player.magic_skill + 2
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 2
                        num_of_points_added = 2
                        points_added = True
                    elif quantity_of_points_to_add == "3":
                        classes_and_objects.player.magic_skill = classes_and_objects.player.magic_skill + 3
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 3
                        num_of_points_added = 3
                        points_added = True
                    elif quantity_of_points_to_add == "4":
                        classes_and_objects.player.magic_skill = classes_and_objects.player.magic_skill + 4
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 4
                        num_of_points_added = 4
                        points_added = True
                    elif quantity_of_points_to_add == "5":
                        classes_and_objects.player.magic_skill = classes_and_objects.player.magic_skill + 5
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 5
                        num_of_points_added = 5
                        points_added = True
                    else:
                        quantity_of_points_to_add = input("Please enter a number from 1-5: ")
                #while loop that checks to see if you're trying to add too many points. If you added too many points, it fixes the issue.
                while num_of_points_added > (classes_and_objects.player.points_to_allocate + num_of_points_added): 
                    print("You cannot add more points than you have.")
                    classes_and_objects.player.magic_skill = classes_and_objects.player.magic_skill - num_of_points_added
                    classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate + num_of_points_added
                    break
                print()
                print("Your magic skill is now: " + str(classes_and_objects.player.magic_skill))
                print()

                #Depending on the player's magic skill, the player is notified that they can now use certain spells:
                if classes_and_objects.player.magic_skill >= 25 and classes_and_objects.player.magic_skill < 35:
                    print("You are now a newbie magician. You learn the Sparks spell. ")
                    input("Press ENTER to continue.")
                    print()
                    print("You can now use the following list of spells:")
                    print(classes_and_objects.sparks_spell.description)
                    print()
                elif classes_and_objects.player.magic_skill >= 35 and classes_and_objects.player.magic_skill < 45:
                    print("You are now an experienced magician. You learn the Healing Spell.")
                    input("Press ENTER to continue.")
                    print()
                    print("You can now use the following list of spells:")
                    print(classes_and_objects.sparks_spell.description)
                    print(classes_and_objects.healing_spell.description)
                elif classes_and_objects.player.magic_skill >= 45 and classes_and_objects.player.magic_skill < 55:
                    print("You are now a Wizard's apprentice. You learn the fireball spell.")
                    input("Press ENTER to continue.")
                    print()
                    print("You can now use the following list of spells:")
                    print(classes_and_objects.sparks_spell.description)
                    print(classes_and_objects.healing_spell.description)
                    print(classes_and_objects.fire_ball_spell.description)
                elif classes_and_objects.player.magic_skill >= 55 and classes_and_objects.player.magic_skill < 65:
                    print("You are now a journeyman wizard. You learn the telekinesis spell.")
                    input("Press ENTER to continue.")
                    print()
                    print("You can now use the following list of spells:")
                    print(classes_and_objects.sparks_spell.description)
                    print(classes_and_objects.healing_spell.description)
                    print(classes_and_objects.fire_ball_spell.description)
                    print(classes_and_objects.telekinesis_spell.description)


            #Amor skill
            if skill_to_allocate_points_to == "5":
                quantity_of_points_to_add = input("How many points would you like to add to your armor skill? ")
                points_added = False
                while points_added == False:
                    if quantity_of_points_to_add == "1":
                        classes_and_objects.player.armor_skill = classes_and_objects.player.armor_skill + 1
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 1
                        num_of_points_added = 1
                        points_added = True
                    elif quantity_of_points_to_add == "2":
                        classes_and_objects.player.armor_skill = classes_and_objects.player.armor_skill + 2
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 2
                        num_of_points_added = 2
                        points_added = True
                    elif quantity_of_points_to_add == "3":
                        classes_and_objects.player.armor_skill = classes_and_objects.player.armor_skill + 3
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 3
                        num_of_points_added = 3
                        points_added = True
                    elif quantity_of_points_to_add == "4":
                        classes_and_objects.player.armor_skill = classes_and_objects.player.armor_skill + 4
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 4
                        num_of_points_added = 4
                        points_added = True
                    elif quantity_of_points_to_add == "5":
                        classes_and_objects.player.armor_skill = classes_and_objects.player.armor_skill + 5
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 5
                        num_of_points_added = 5
                        points_added = True
                    else:
                        quantity_of_points_to_add = input("Please enter a number from 1-5: ")
                #while loop that checks to see if you're trying to add too many points. If you added too many points, it fixes the issue.
                while num_of_points_added > (classes_and_objects.player.points_to_allocate + num_of_points_added): 
                    print("You cannot add more points than you have.")
                    classes_and_objects.player.armor_skill = classes_and_objects.player.armor_skill - num_of_points_added
                    classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate + num_of_points_added
                    break
                print("Your armor skill is now: " + str(classes_and_objects.player.armor_skill))
            
            #Barter skill
            if skill_to_allocate_points_to == "6":
                quantity_of_points_to_add = input("How many points would you like to add to your barter skill? ")
                points_added = False
                while points_added == False:
                    if quantity_of_points_to_add == "1":
                        classes_and_objects.player.barter_skill = classes_and_objects.player.barter_skill + 1
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 1
                        num_of_points_added = 1
                        points_added = True
                    elif quantity_of_points_to_add == "2":
                        classes_and_objects.player.barter_skill = classes_and_objects.player.barter_skill + 2
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 2
                        num_of_points_added = 2
                        points_added = True
                    elif quantity_of_points_to_add == "3":
                        classes_and_objects.player.barter_skill = classes_and_objects.player.barter_skill + 3
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 3
                        num_of_points_added = 3
                        points_added = True
                    elif quantity_of_points_to_add == "4":
                        classes_and_objects.player.barter_skill = classes_and_objects.player.barter_skill + 4
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 4
                        num_of_points_added = 4
                        points_added = True
                    elif quantity_of_points_to_add == "5":
                        classes_and_objects.player.barter_skill = classes_and_objects.player.barter_skill + 5
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 5
                        num_of_points_added = 5
                        points_added = True
                    else:
                        quantity_of_points_to_add = input("Please enter a number from 1-5: ")
                #while loop that checks to see if you're trying to add too many points. If you added too many points, it fixes the issue.
                while num_of_points_added > (classes_and_objects.player.points_to_allocate + num_of_points_added): 
                    print("You cannot add more points than you have.")
                    classes_and_objects.player.barter_skill = classes_and_objects.player.barter_skill - num_of_points_added
                    classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate + num_of_points_added
                    break
                print("Your barter skill is now: " + str(classes_and_objects.player.barter_skill))
            
            #Speed
            if skill_to_allocate_points_to == "7":
                quantity_of_points_to_add = input("How many points would you like to add to your speed? ")
                points_added = False
                while points_added == False:
                    if quantity_of_points_to_add == "1":
                        classes_and_objects.player.speed = classes_and_objects.player.speed + 1
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 1
                        num_of_points_added = 1
                        points_added = True
                    elif quantity_of_points_to_add == "2":
                        classes_and_objects.player.speed = classes_and_objects.player.speed + 2
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 2
                        num_of_points_added = 2
                        points_added = True
                    elif quantity_of_points_to_add == "3":
                        classes_and_objects.player.speed = classes_and_objects.player.speed + 3
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 3
                        num_of_points_added = 3
                        points_added = True
                    elif quantity_of_points_to_add == "4":
                        classes_and_objects.player.speed = classes_and_objects.player.speed + 4
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 4
                        num_of_points_added = 4
                        points_added = True
                    elif quantity_of_points_to_add == "5":
                        classes_and_objects.player.speed = classes_and_objects.player.speed + 5
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 5
                        num_of_points_added = 5
                        points_added = True
                    else:
                        quantity_of_points_to_add = input("Please enter a number from 1-5: ")
                #while loop that checks to see if you're trying to add too many points. If you added too many points, it fixes the issue.
                while num_of_points_added > (classes_and_objects.player.points_to_allocate + num_of_points_added): 
                    print("You cannot add more points than you have.")
                    classes_and_objects.player.speed = classes_and_objects.player.speed - num_of_points_added
                    classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate + num_of_points_added
                    break
                print("Your speed is now: " + str(classes_and_objects.player.speed))

            #Stealth
            if skill_to_allocate_points_to == "8":
                quantity_of_points_to_add = input("How many points would you like to add to your stealth? ")
                points_added = False
                while points_added == False:
                    if quantity_of_points_to_add == "1":
                        classes_and_objects.player.stealth = classes_and_objects.player.stealth + 1
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 1
                        num_of_points_added = 1
                        points_added = True
                    elif quantity_of_points_to_add == "2":
                        classes_and_objects.player.stealth = classes_and_objects.player.stealth + 2
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 2
                        num_of_points_added = 2
                        points_added = True
                    elif quantity_of_points_to_add == "3":
                        classes_and_objects.player.stealth = classes_and_objects.player.stealth + 3
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 3
                        num_of_points_added = 3
                        points_added = True
                    elif quantity_of_points_to_add == "4":
                        classes_and_objects.player.stealth = classes_and_objects.player.stealth + 4
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 4
                        num_of_points_added = 4
                        points_added = True
                    elif quantity_of_points_to_add == "5":
                        classes_and_objects.player.stealth = classes_and_objects.player.stealth + 5
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 5
                        num_of_points_added = 5
                        points_added = True
                    else:
                        quantity_of_points_to_add = input("Please enter a number from 1-5: ")
                #while loop that checks to see if you're trying to add too many points. If you added too many points, it fixes the issue.
                while num_of_points_added > (classes_and_objects.player.points_to_allocate + num_of_points_added): 
                    print("You cannot add more points than you have.")
                    classes_and_objects.player.stealth = classes_and_objects.player.stealth - num_of_points_added
                    classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate + num_of_points_added
                    break
                print("Your stealth is now: " + str(classes_and_objects.player.stealth))

            #Strength
            if skill_to_allocate_points_to == "9":
                quantity_of_points_to_add = input("How many points would you like to add to your strength? ")
                points_added = False
                while points_added == False:
                    if quantity_of_points_to_add == "1":
                        classes_and_objects.player.strength = classes_and_objects.player.strength + 1
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 1
                        num_of_points_added = 1
                        points_added = True
                    elif quantity_of_points_to_add == "2":
                        classes_and_objects.player.strength = classes_and_objects.player.strength + 2
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 2
                        num_of_points_added = 2
                        points_added = True
                    elif quantity_of_points_to_add == "3":
                        classes_and_objects.player.strength = classes_and_objects.player.strength + 3
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 3
                        num_of_points_added = 3
                        points_added = True
                    elif quantity_of_points_to_add == "4":
                        classes_and_objects.player.strength = classes_and_objects.player.strength + 4
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 4
                        num_of_points_added = 4
                        points_added = True
                    elif quantity_of_points_to_add == "5":
                        classes_and_objects.player.strength = classes_and_objects.player.strength + 5
                        classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate - 5
                        num_of_points_added = 5
                        points_added = True
                    else:
                        quantity_of_points_to_add = input("Please enter a number from 1-5: ")
                #while loop that checks to see if you're trying to add too many points. If you added too many points, it fixes the issue.
                while num_of_points_added > (classes_and_objects.player.points_to_allocate + num_of_points_added): 
                    print("You cannot add more points than you have.")
                    classes_and_objects.player.strength = classes_and_objects.player.strength - num_of_points_added
                    classes_and_objects.player.points_to_allocate = classes_and_objects.player.points_to_allocate + num_of_points_added
                    break
                print("Your strength is now: " + str(classes_and_objects.player.strength))

            #sets the experience points back to 0 so the player can start leveling up again.
            classes_and_objects.player.experience_points = 0
            input("Press ENTER to continue.")
def refresh():
    '''This function refreshes the game by checking to see if the player is dead, can level up, etc.'''
    level_up()
    player_dead()
def view_character_stats():
    '''This function allows the player to view their stats in the game. Add options for the character to see their available moves and spells.'''
    print("______________")
    print()
    print("CHARACTER STATS")
    print("______________")
    print()
    print("Name: " + classes_and_objects.player.player_name)
    print("Class: " + classes_and_objects.player.player_class)
    print("Battle cry: " + classes_and_objects.player.player_battle_cry)
    print("Level: " + str(classes_and_objects.player.player_level))
    print("Dungeon: " + classes_and_objects.player.dungeon_location)
    print("Location: Room " + str(classes_and_objects.player.room_location))
    print("Hit Points: " + str(classes_and_objects.player.hit_points) + "/" + str(classes_and_objects.player.max_hit_points))
    print("Sword skill: " + str(classes_and_objects.player.sword_skill))
    print("Archery skill: " + str(classes_and_objects.player.archery_skill))
    print("Magic skill: " + str(classes_and_objects.player.magic_skill))
    print("Armor skill: " + str(classes_and_objects.player.armor_skill))
    print("Barter skill: " + str(classes_and_objects.player.barter_skill))
    print("Speed: " + str(classes_and_objects.player.speed))
    print("Stealth: " + str(classes_and_objects.player.stealth))
    print("Strength: " + str(classes_and_objects.player.strength))
    print("Experience points: " + str(classes_and_objects.player.experience_points))
    print("Points to next level: " + str(10 - classes_and_objects.player.experience_points))
def knight_class():
    '''This function will change all of the attributes of the Player_Character class to match that of the Knight class. It is called by the character_creation() function.'''
    print()
    classes_and_objects.player.hit_points = 100
    classes_and_objects.player.max_hit_points = 100
    classes_and_objects.player.sword_skill = 50
    classes_and_objects.player.archery_skill = 30
    classes_and_objects.player.magic_skill = 20
    classes_and_objects.player.armor_skill = 50
    classes_and_objects.player.speed = 20
    classes_and_objects.player.stealth = 20
    classes_and_objects.player.strength = 50
    classes_and_objects.player.barter_skill = 20
    classes_and_objects.player.player_class = "Knight"
    return "You are now playing as a knight."
def wizard_class():
    '''This function will change all of the attributes of the Player_Character class to match that of the wizard class. It is called by the character_creation() function.'''
    print()
    classes_and_objects.player.hit_points = 60
    classes_and_objects.player.max_hit_points = 60
    classes_and_objects.player.sword_skill = 30
    classes_and_objects.player.archery_skill = 20
    classes_and_objects.player.magic_skill = 50
    classes_and_objects.player.armor_skill = 20
    classes_and_objects.player.speed = 30
    classes_and_objects.player.stealth = 30
    classes_and_objects.player.strength = 20
    classes_and_objects.player.barter_skill = 30
    classes_and_objects.player.player_class = "Wizard"
    return "You are now playing as a wizard."
def thief_class():
    '''This function will change all of the attributes of the Player_Character class to match that of the thief class. It is called by the character_creation() function.'''
    print()
    classes_and_objects.player.hit_points = 70
    classes_and_objects.player.max_hit_points = 70
    classes_and_objects.player.sword_skill = 30
    classes_and_objects.player.archery_skill = 50
    classes_and_objects.player.magic_skill = 20
    classes_and_objects.player.armor_skill = 30
    classes_and_objects.player.speed = 50
    classes_and_objects.player.stealth = 50
    classes_and_objects.player.strength = 30
    classes_and_objects.player.barter_skill = 20
    classes_and_objects.player.player_class = "Thief"
    return "You are now playing as an thief."
def character_creation():
    '''This function enables the player to create his character by typing the name and picking from a set of premade characters.'''

    print("______________")
    print()
    print("CHARACTER CREATION")
    print("______________")
    print()

    #Player chooses character name and program verifies if it is correct.
    name_correct = False
    while name_correct == False:
        classes_and_objects.player.player_name = input("What is your name? ")
        print()
        print("Hello " + classes_and_objects.player.player_name)
        print()
        print ("Is " + classes_and_objects.player.player_name + " the correct name?")
        yes_or_no = input("Type y for yes and n for no. ")
        if yes_or_no == "y":
            print()
            print("Excellent. Your name is now " + classes_and_objects.player.player_name + ".")
            name_correct = True
            break

    #Asks the player to choose from a set of premade characters.
    print()
    print("Choose your class... ")
    print()

    print("1. Knight")
    print("Starting Hit Points: 100")
    print("Sword skill: 50")
    print("Archery skill: 30")
    print("Magic skill: 20")
    print("Armor skill: 50")
    print("Speed: 20")
    print("Stealth: 20")
    print("Strength: 50")
    print("Barter skill: 20")
    print()

    print("2. Wizard")
    print("Starting Hit Points: 60")
    print("Sword skill: 30")
    print("Archery skill: 20")
    print("Magic skill: 50")
    print("Armor skill: 20")
    print("Speed: 30")
    print("Stealth: 30")
    print("Strength: 20")
    print("Barter skill: 30")
    print()

    print("3. Thief")
    print("Starting Hit Points: 70")
    print("Sword skill: 30")
    print("Archery skill: 50")
    print("Magic skill: 20")
    print("Armor skill: 30")
    print("Speed: 50")
    print("Stealth: 50")
    print("Strength: 30")
    print("Barter skill: 20")
    print()

    character_chosen = int(input("Press 1 for Knight, 2 for Wizard, or 3 for Thief: "))

    #verifies that the player selected the correct class. If so, it calls the class function to change the player's attributes.
    class_correct = False
    while class_correct == False:
        if character_chosen == 1:
            yes_or_no2 = input("Are you sure you want to play as a knight? y/n ")
            if yes_or_no2 == "y":
                knight_class()
                break
            else:
                print()
                character_chosen = int(input("Press 1 for knight, 2 for wizard, or 3 for thief: "))
        elif character_chosen == 2:
            yes_or_no2 = input("Are you sure you want to play as a wizard? y/n ")
            if yes_or_no2 == "y":
                wizard_class()
                break
            else:
                print()
                character_chosen = int(input("Press 1 for kight, 2 for wizard, or 3 for thief: "))
        elif character_chosen == 3:
            yes_or_no2 = input("Are you sure you want to play as a thief? y/n ")
            if yes_or_no2 == "y":
                thief_class()
                break
            else:
                print()
                character_chosen = int(input("Press 1 for kight, 2 for wizard, or 3 for thief: "))

    #Lets the player define their battle cry.
    battle_cry_correct = False
    while battle_cry_correct == False:
        classes_and_objects.player.player_battle_cry = input("Type your battle cry: ")
        yes_or_no3 = input("Is " + classes_and_objects.player.battle_cry() + " correct? y/n: ")
        if yes_or_no3 == "y":
            battle_cry_correct = True
            break

    #Lets the player view the class information with a view_character_stats() function.
    print()
    input("Press ENTER to view character stats.")
    view_character_stats()
    print()
    input("Press ENTER to continue.")


    print()
    return "Character creation complete..."
def start_menu():
    '''This is the start menu of the game. It is called by the main() function. It displays the title of the game and asks the user to either start the game or view the game instructions.'''
    print()
    #displays the title of the game.
    print("===============")
    print()
    print(" DUNGEON SEEK")
    print()
    print("===============")
    print()
    print("-  A game made by Jaden and Jorey Mounteer using python 3")
    print()

    #Asks the user to press ENTER to start the game. Stores the user input in a global variable called start_game. In the future, we can add the option for
    # the user to also press i and then ENTER to view the game instructions.
    global start_game
    start_game = input("Press ENTER to start the game. ")
    print()

    #checks to see if user input the correct characters.
    while start_game != "":
        start_game = input("Please press ENTER to start the game: ")

    #sets start_game to the boolean value of True.
    start_game = True

    #breaks out of the function and tells the user that the game is being launched.

    return "Game launched..."