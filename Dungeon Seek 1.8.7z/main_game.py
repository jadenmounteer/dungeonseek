""" This file runs the game. It contains the main() function. """

#imports the game_logic module.
import classes_and_objects
import game_logic

def main():
    '''This is the first function called. It calls the start_menu function and then proceeds with the rest of the game.'''
    
    #calls the start_menu() function.
    print()
    game_logic.start_menu()
    print()

    #Calls the character_creation() function.
    game_logic.character_creation()

    #testing level up system.
    classes_and_objects.player.experience_points = 10
    game_logic.refresh()

    #calls the room_level_1() function which throws the player into the first dungeon: Tomb of the Undead.
    game_logic.dungeon_level_1()

    #If the player dies, he is told game over and is only brought to the next dungeon if the player_status == "Alive"
    
    #Displays Game over when the game ends.
    print("Game over.")

#calls the main() function which launches the game.
if __name__ == '__main__':
    main()