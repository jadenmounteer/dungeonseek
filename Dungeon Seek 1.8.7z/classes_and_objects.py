#imports
from random import randint
import game_logic

#CLASSES (Classes of objects in the game, character, zombie, etc.)
class Player_Character:
    """ This is the character class. It contains all of the methods and attributes of the player's character. """
    def __init__(self, hit_points, max_hit_points, sword_skill, archery_skill, magic_skill, armor_skill, speed, stealth, strength, experience_points, barter_skill, player_level, player_class,
     player_name, points_to_allocate, room_location, dungeon_location, player_battle_cry, inventory, gold, player_in_combat, base_amount_of_damage, attacking_with, player_status):
        '''This function configures the player's attributes.'''
        self.hit_points = 0
        self.max_hit_points = 0 #These will increase as you level up. Your current hitpoints can never surpass your max hit points.
        self.sword_skill = 0
        self.archery_skill = 0
        self.magic_skill = 0
        self.armor_skill = 0
        self.speed = 0
        self.stealth = 0
        self.strength = 0
        self.experience_points = 0
        self.barter_skill = 0
        self.player_level = 1
        self.player_class = "Not chosen."
        self.player_name = "Not chosen."
        self.points_to_allocate = 0 #You can allocate these points when you level up.
        self.room_location = 0
        self.dungeon_location = ""
        self.player_battle_cry = "For Narnia!"
        self.inventory = []
        self.gold = 0
        self.player_in_combat = False
        self.base_amount_of_damage = 0 #This is the base amount of damage caused by the player while attacking an enemy using a sword, spell, or bow.
        self.attacking_with = "" #This attribute is updated when the player is attacking with a certain spell or weapon. It is used to see what kind of influence it has on the enemy.
        self.player_status = ""
    def battle_cry(self):
        return self.player_name + ": " + self.player_battle_cry + "!"
    def player_turn(self):
        """
        This function is called when it is the player's turn in combat.
        Shows that it is the player's turn. Asks what you would like to do.
        Displays the available options and the chance of success based on the enemy's attributes.
        Returns how the player would like to proceed. 
        """
        print()
        print("It is " + self.player_name + "'s turn!")
        print()

        #Asks the player to take action and creates a variable to store the player's action.
        print("What would you like to do?")
        player_action = ""
        print()

        #shows the actions available. Maybe put this in a while loop so you can periodically see your stats.
        action_taken = False 
        while action_taken == False:
            print("1 Attack with sword.")
            print("2 Attack with magic.")
            print("3 Attack with bow.")
            print("4 Use item.")
            print("5 Sneak away.")
            print("6 Run away.")
            print("7 View character stats.")
            player_action = input("Type the number of your action: ")
            
            #depending on the player's action, do something: 
            if player_action == "1":
                print("You attack with your sword.")
                action_taken = True
                break
            elif player_action == "2":
                self.use_spell()
                action_taken = True
                break
            elif player_action == "3":
                print("You attack with your bow.")
                action_taken = True
                break
            elif player_action == "4":
                print("You use an item.")
                action_taken = True
                break
            elif player_action == "5":
                print("You sneak away.")
                action_taken = True
            elif player_action == "6":
                print("You run away.")
                action_taken = True
                break 
            elif player_action == "7":
                game_logic.view_character_stats()
            else:
                print("Please type a number from 1 to 7.")

            print()
            input("Press ENTER to continue.")
        return player_action
    def player_turn_non_combat(self):
        """
        This function is called when the player enters an empty room or after combat.
        Asks what you would like to do.
        Displays the available options: Look around, use spell, go left, go right, view stats, etc.
        Returns how the player would like to proceed. 
        """
    def use_spell(self):
        """ 
        This function is called by the  player_turn or the player_turn_non_combat functions.
        The player will now be able to choose which spell to use. If the player is in combat, his combat spells to combat things. If not, his spells do different things.
        The function first checks the player's magic level and determins the spells he can use from there.
        Then the function checks if the player is in combat and calls the correct function from the spell object.
        
         """
        print()
        print("Choose a spell to use...")

        #Gives the player a list of spells to use depending on the player's magic skill.

        spell_chosen = False

        # 1st tier spells
        if self.magic_skill >= 25 and self.magic_skill < 35:
            print()
            print("1 " + sparks_spell.description)
            print()
            spell_to_use = input("Type the number of the spell you wish to use: ")      
            #Depending on the spell the player chooses, call the function of that spell from the spell object.
            while spell_chosen != True:
                if spell_to_use == "1":
                    #If the player is in combat, call the use_spell_in_combat() function. If the player is outside of combat, call the non-combat function.
                    if self.player_in_combat == True:
                        print(sparks_spell.use_spell_in_combat())
                    elif self.player_in_combat == False:
                        print(sparks_spell.use_spell_outside_of_combat())
                    spell_chosen = False
                    break
        
        # 2nd tier spells
        elif self.magic_skill >= 35 and self.magic_skill < 45:
            print()
            print("1 " + sparks_spell.description)
            print("2 " + healing_spell.description)
            spell_to_use = input("Type the number of the spell you wish to use: ")
            #Depending on the spell the player chooses, call the function of that spell from the spell object.
            while spell_chosen != True:
                #Sparks spell
                if spell_to_use == "1":
                    #If the player is in combat, call the use_spell_in_combat() function. If the player is outside of combat, call the non-combat function.
                    if self.player_in_combat == True:
                        print(sparks_spell.use_spell_in_combat())
                    elif self.player_in_combat == False:
                        print(sparks_spell.use_spell_outside_of_combat())
                    spell_chosen = True
                    break
                #Healing spell
                elif spell_to_use == "2":
                    if self.player_in_combat == True:
                        print(healing_spell.use_spell_in_combat())
                    elif self.player_in_combat == False:
                        print(healing_spell.use_spell_outside_of_combat())
                    spell_chosen = True
                    break
                        
        # 3rd tier spells
        elif self.magic_skill >= 45 and self.magic_skill < 55:
            print("1 " + sparks_spell.description)
            print("2 " + healing_spell.description)
            print("3 " + fire_ball_spell.description)
            spell_to_use = input("Type the number of the spell you wish to use: ")
            #Depending on the spell the player chooses, call the function of that spell from the spell object.
            while spell_chosen != True:
                #Sparks spell
                if spell_to_use == "1":
                    #If the player is in combat, call the use_spell_in_combat() function. If the player is outside of combat, call the non-combat function.
                    if self.player_in_combat == True:
                        print(sparks_spell.use_spell_in_combat())
                    elif self.player_in_combat == False:
                        print(sparks_spell.use_spell_outside_of_combat())
                    spell_chosen = True
                    break
                #Healing spell
                elif spell_to_use == "2":
                    if self.player_in_combat == True:
                        print(healing_spell.use_spell_in_combat())
                    elif self.player_in_combat == False:
                        print(healing_spell.use_spell_outside_of_combat())
                    spell_chosen = True
                    break
                #Fireball spell
                elif spell_to_use == "3":
                    if self.player_in_combat == True:
                        print(fire_ball_spell.use_spell_in_combat())
                    elif self.player_in_combat == False:
                        print(fire_ball_spell.use_spell_outside_of_combat())
                    spell_chosen = True
                    break

        # 4th tier spells
        elif self.magic_skill >= 55 and self.magic_skill < 65:
            print()
            print("1 " + sparks_spell.description)
            print("2 " + healing_spell.description)
            print("3 " + fire_ball_spell.description)
            print("4 " + telekinesis_spell.description)
            spell_to_use = input("Type the number of the spell you wish to use: ")
            #Depending on the spell the player chooses, call the function of that spell from the spell object.
            while spell_chosen != True:
                #Sparks spell
                if spell_to_use == "1":
                    #If the player is in combat, call the use_spell_in_combat() function. If the player is outside of combat, call the non-combat function.
                    if self.player_in_combat == True:
                        print(sparks_spell.use_spell_in_combat())
                    elif self.player_in_combat == False:
                        print(sparks_spell.use_spell_outside_of_combat())
                    spell_chosen = True
                    break
                #Healing spell
                elif spell_to_use == "2":
                    if self.player_in_combat == True:
                        print(healing_spell.use_spell_in_combat())
                    elif self.player_in_combat == False:
                        print(healing_spell.use_spell_outside_of_combat())
                    spell_chosen = True
                    break
                #Fireball spell
                elif spell_to_use == "3":
                    if self.player_in_combat == True:
                        print(fire_ball_spell.use_spell_in_combat())
                    elif self.player_in_combat == False:
                        print(fire_ball_spell.use_spell_outside_of_combat())
                    spell_chosen = True
                    break
                #Telekinesis spell
                elif spell_to_use == "4":
                    if self.player_in_combat == True:
                        print(telekinesis_spell.use_spell_in_combat())
                    elif self.player_in_combat == False:
                        print(telekinesis_spell.use_spell_outside_of_combat())
                    spell_chosen = True
                    break
            return ""
    def use_item(self):
        """ This function is called by the player_turn() function or the player_turn_non_combat() function.
        The player will see the items currently in his inventory.
        The player will be able to see """
#Create a Trader class here. He can have methods of introducing the player to each dungeon, trading, etc. Maybe he can be the final boss.

#Enemy classes
class Zombie:
    def __init__(self, name, hit_points, strength, status, speed, armor, weakness, base_amount_of_damage, attacking_with, bonus_damage):
        self.name = name
        self.hit_points = hit_points
        self.strength = strength
        self.status = status
        self.speed = speed
        self.armor = armor
        self.weakness = weakness
        self.base_amount_of_damage = base_amount_of_damage
        self.attacking_with = ""
        self.bonus_damage = bonus_damage
    def battle_cry(self):
        '''This function makes the zombie moan.'''
        return self.name + ": " + "Uuuhhh"
    def appear(self):
        '''This function describes the zombie appearing to the player. Using the randint function, it chooses from multiple descriptions.'''
        random_number = randint(1, 2)
        if random_number == 1:
            print("A figure limps towards you from the distance. As it draws closer you can see that it is a living corpse.")
            print("Its loose jaw falls open and a manacing moan leaves its mouth. It is coming straight for you.")
            input("Press ENTER to continue.")
        elif random_number == 2:
            print('''Jeff the zombie approaches...''')
            input("Press ENTER to continue.") 
    def turn(self):
        '''
        This function is called when it is the zombie's turn in combat.
        Using a random number, an attack is chosen for the zombie. 
        The zombie also has a 50% chance of moaning, which counts as a turn but adds 10 bonus damage to any future attacks.
        '''
        action_chosen = randint(1, 2)
        #The zombie will first see if it has any bonus damage. If it doesn't, it has a 50% chance of moaning in order to accumulate bonus damage.
        zombie_wants_to_moan = randint(1, 2)
        if self.bonus_damage <= 0 and zombie_wants_to_moan == 1:
            print(self.moan())
            return input("Press ENTER to continue.")
        if action_chosen == 1:
            print(self.bite())
            return input("Press ENTER to continue.")
        elif action_chosen == 2:
            print(self.scratch())
            return input("Press ENTER to continue.")
    def bite(self):
        """ 
        This function makes the zombie bite. It is called by the turn() function. It describes the zombie biting at the player and calculates and returns the damage caused. 
        This function will also need to change an attacking_with attribute for the zombie.
        """
        #Changes the attacking_with attribute
        self.attacking_with = "Teeth"
        #Determines the base amount of damage caused by dividing the zombie's strength skill by 10 to get the modifier, and then adding that to a random number between 1 and 20.
        self.base_amount_of_damage = (self.strength / 10) + randint(1, 20) + self.base_amount_of_damage
        print()
        #Describes the zombie biting at the player based on how much damage it will cause.
        if self.base_amount_of_damage >= 15:
            return self.name + "'s mouth gapes open as it attempts to bite you."
        else:
            return self.name + "'s mouth gapes open, showing rotting teath as it attempts to bite you."
    def scratch(self):
        """ 
        This function makes the zombie scratch. It is called by the turn() function. It describes the zombie scratching at the player and calculates and returns the damage caused.
        This function will also need to change an attacking_with attribute for the zombie.
         """
        #Changes the attacking_with attribute
        self.attacking_with = "Fingernails"
        #Determines the base amount of damage caused by dividing the zombie's strength skill by 10 to get the modifier, and then adding that to a random number between 1 and 20.
        self.base_amount_of_damage = (self.strength / 10) + randint(1, 20) + self.base_amount_of_damage
        print()
        #Describes the zombie biting at the player based on how much damage it will cause.
        if self.base_amount_of_damage >= 15:
            return self.name + " reaches out with rotting hands and fingernails to attack."
        else:
            return self.name + " limps forward, a rotting hand outstretched as it reaches for you."
    def moan(self):
        """ This function makes the zombie moan and accumulate bonus damage. It is called by the turn() function and counts as a turn. """
        #sets attacking with to "Healing" so that it can't miss.
        self.attacking_with = "Healing"
        #Adds 10 to bonus damage which will be added to the base amount of damage during the next attacks.
        self.bonus_damage = 10
        return self.name + " opens its mouth and gives off a blood-curdling moan. It seems to be getting angrier."
    def death(self, cause_of_death):
        """ 
        This function takes the cause of death as a parameter. (player.attacking_with). Using an if statement, it outputs a description of the death.
        Causes of death include: Electricity, Psychic, Steel, Fire.
         """
        if cause_of_death == "Electricity":
            return self.name + " goes stiff as the electricity runs it's course through its body. Smoke rises from its head and it topples over defeated."
        elif cause_of_death == "Fire":
            return self.name + " catches fire. It doesn't seem to notice as it stumbles toward you. With its next step, it looses its footing and topples forward in a burning heap."
        else:
            return "Cause of death unknown."
class Poltergiest:
    def __init__(self, name, hit_points, archery, anger, armor):
        self.name = name
        self.hit_points = hit_points
        self.archery = archery
        self.anger = anger
        self.armor = armor
    def battle_cry(self):
        '''This function is the Poltergiest's battle cry.'''
        print(self.name + ": " + "oooooh!")
        return ""
    def turn(self):
        '''This function is called when it is the Poltergiest's turn in combat.'''
        print(self.name + " attacks!")
        print()
        input("Press ENTER to continue.")
class Quiz_Poltergiest(Poltergiest):
    def __init__(self, name, hit_points, archery, anger, armor, weakness):
        self.name = name
        self.hit_points = hit_points
        self.archery = archery
        self.anger = anger
        self.armor = armor
        self.weakness = weakness
    def quiz(self):
        '''This asks the player questions'''
     #input(self.name + ": " + "What month of the year has twenty eight days?")
        num = randint(1, 3)
        ghostRiddle1 = "What has to be broken before you can use it?"
        ghostRiddle2 = "What month has 28 days in it?"
        ghostRiddle3 = "I shave everyday, but my beard stays the same, what am I?"
        print(self.name + ": " + "I have a riddle for you, answer incorrectly and you die...")
        print("")

        if num == 1:
            print(self.name + ": " + ghostRiddle1)    
        elif num == 2:
            print(self.name + ": " + ghostRiddle2)
        elif num == 3:
            print(self.name+ ": " + ghostRiddle3)

#Boss classes
class Vampire:
    def __init__(self, name, hit_points, strength, status, speed):
        self.name = name
        self.hit_points = hit_points
        self.strength = strength
        self.status = status
        self.speed = speed

#Weapon classes. Maybe have these act just like spells. Each weapon has unique attributes.
class Sword:
    def __init__(self, name, hit_points, strength, status, speed):
        self.name = name
        self.hit_points = hit_points
        self.strength = strength
        self.status = status
        self.speed = speed
class Bow:
    def __init__(self, name, hit_points, strength, status, speed):
        self.name = name
        self.hit_points = hit_points
        self.strength = strength
        self.status = status
        self.speed = speed

#Spell classes
class Healing_spell:
    def __init__(self, description, attack_type):
        self.description = description
        self.attack_type = attack_type
    def use_spell_in_combat(self):
        """ This function calls the healing spell if the player is in combat. The spell will heal the player and then end his turn.
         Use a random int and the player's magic skill to determine how many hp it restores. """

        #Sets the player's base amount of damage done to 0.
        player.base_amount_of_damage = 0
        #sets the player attacking with to healing
        player.attacking_with = self.attack_type
        #Determins the amount to heal the player caused by dividing the player's magic skill by 10 to get the modifier, and then adding that to a random number between 1 and 20.
        hit_points_healed = (player.magic_skill / 10) + randint(1, 20)
        #Determins whether or not the spell will heal the player for more than his max hit points. If it will, it subtracts 1 from the hit points healed until it is equal to the max hit points.
        while (player.hit_points + hit_points_healed) > player.max_hit_points:
            hit_points_healed -= 1

        #Adds the hit_points_healed to the player's hit points.
        player.hit_points += hit_points_healed

        #determins the description of what happens based on the hp points restored. Returns how much hp was restored.
        return "You use the healing spell in combat to heal you " + str(hit_points_healed) + " hit points. You now have " + str(player.hit_points) + " hit points."
    def use_spell_outside_of_combat(self):
        """ This function calls the healing spell if the player is not in combat. """

        

        return "You use the healing spell outside of combat."
class Fireball_spell:
    def __init__(self, description, attack_type):
        self.description = description
        self.attack_type = attack_type
    def use_spell_in_combat(self):
        """ 
        This function calls the fireball spell if the player is in combat.
        Changes the attacking_with variable to be the fireball attack type.
        Calculates the base mount of damage.

        """
        print()
        #Changes the variable attacking_with to be fireball attack type (Fire).
        player.attacking_with = fire_ball_spell.attack_type
        #Determines the base amount of damage caused by dividing the player's magic skill by 10 to get the modifier, and then adding that to a random number between 1 and 20.
        player.base_amount_of_damage = (player.magic_skill / 10) + randint(1, 20)
        #Returns the base amount of damage caused by the spell and the description based on the number. Uses an if statement.
        if player.base_amount_of_damage >= 20:
            return "A ball of blue fire erupts from your outstretched arms and spins through the air."
        else:
            return player.player_name + " attacks with fireball spell."
    def use_spell_outside_of_combat(self):
        """ 
        This function calls the fireball spell if the player is not in combat.
        
        """

        return player.player_name + " uses the fireball spell."
class Telekinesis_spell:
    def __init__(self, description, attack_type):
        self.description = description
        self.attack_type = attack_type
    def use_spell_in_combat(self):
        """ 
        This function calls the telekinesis spell if the player is in combat.
        Changes the attacking_with variable to be the telekinesis attack type.
        Calculates the base mount of damage.

        """
        print()
        #Changes the variable attacking_with to be telekinesis attack type (Psychic).
        player.attacking_with = telekinesis_spell.attack_type
        #Determines the base amount of damage caused by dividing the player's magic skill by 10 to get the modifier, and then adding that to a random number between 1 and 20.
        player.base_amount_of_damage = (player.magic_skill / 10) + randint(1, 20)
        #Returns the base amount of damage caused by the spell and the description based on the number. Uses an if statement.
    
        return player.player_name + " attacks with telekinesis."
    def use_spell_outside_of_combat(self):
        """ 
        This function calls the telekinesis spell if the player is not in combat.
        
        """
        return "You use the telekinesis spell outside of combat."
class Sparks_spell:
    def __init__(self, description, attack_type):
        self.description = description
        self.attack_type = attack_type
    def use_spell_in_combat(self):
        """ 
        This function calls the sparks spell if the player is in combat.
        This spell will shock an enemy with electricity. Changes the variable attacking_with to the spark spell attack type.
        Using the player's magic skill and a random number, determines the base amount of damage it will cause.

        """
        print()
        #Changes the variable attacking_with to be sparks_spell attack type (Electricity) in the player object.
        player.attacking_with = sparks_spell.attack_type
        #Determines the base amount of damage caused by dividing the player's magic skill by 10 to get the modifier, and then adding that to a random number between 1 and 20.
        player.base_amount_of_damage = (player.magic_skill / 10) + randint(1, 20)
        #Returns the base amount of damage caused by the spell and the description based on the number. Uses an if statement.
        if player.base_amount_of_damage >= 20:
            return "Streaks of blue lightning flash from your outstretched hands."
        elif player.base_amount_of_damage >= 10:
            return "Bright sparks erupt from your fingertips."
        else:
            return player.player_name + " attacks with Sparks spell."
    def use_spell_outside_of_combat(self):
        """ 
        This function calls the sparks spell if the player is not in combat.
        This spell will produce light for the player to see. Maybe we can have the player operate machinery or something in certain areas.
        
        """
        print()
        return "You use the sparks speel while not in combat."
   
#OBJECTS (Objects of classes in the game.) Put these in the dungeon spawner functions, except for the player.
player = Player_Character(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, "Not chosen", "Not chosen", 0, 0, "", "For Narnia!", [], 0, False, 0, "", "Alive")

#Spell Objects. Can I put this code in the Level_up() function? That way these are called into existence when the player learns the spell?
healing_spell = Healing_spell("Healing Spell - Healing light that pours from your fingertips.", "Healing")
fire_ball_spell = Fireball_spell("Fireball - A ball of fire that envelopes your enemies in flames.", "Fire")
telekinesis_spell = Telekinesis_spell("Telekinesis - You can levitate objects with your mere thought.", "Psychic")
sparks_spell = Sparks_spell("Sparks - Electricity races from your fingertips, sending a shock to your enemies.", "Electricity")

